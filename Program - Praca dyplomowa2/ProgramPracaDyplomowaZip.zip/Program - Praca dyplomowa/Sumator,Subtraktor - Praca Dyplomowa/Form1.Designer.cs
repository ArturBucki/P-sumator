﻿
namespace Sumator_Subtraktor___Praca_Dyplomowa
{
    partial class SumatorSubtraktor
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SumatorSubtraktor));
            this.Ai1 = new System.Windows.Forms.CheckBox();
            this.Bi2 = new System.Windows.Forms.CheckBox();
            this.Ci3 = new System.Windows.Forms.CheckBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.Si1 = new System.Windows.Forms.CheckBox();
            this.Ci = new System.Windows.Forms.CheckBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.C0 = new System.Windows.Forms.CheckBox();
            this.b0 = new System.Windows.Forms.CheckBox();
            this.b1 = new System.Windows.Forms.CheckBox();
            this.b2 = new System.Windows.Forms.CheckBox();
            this.b3 = new System.Windows.Forms.CheckBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.b0wyj = new System.Windows.Forms.CheckBox();
            this.b1wyj = new System.Windows.Forms.CheckBox();
            this.b2wyj = new System.Windows.Forms.CheckBox();
            this.b3wyj = new System.Windows.Forms.CheckBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.CnMinus1 = new System.Windows.Forms.CheckBox();
            this.Cn = new System.Windows.Forms.CheckBox();
            this.Ofl = new System.Windows.Forms.CheckBox();
            this.piatyBit = new System.Windows.Forms.CheckBox();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.pictureBox15 = new System.Windows.Forms.PictureBox();
            this.pictureBox16 = new System.Windows.Forms.PictureBox();
            this.C0SUMXOR = new System.Windows.Forms.PictureBox();
            this.B3SUMR = new System.Windows.Forms.CheckBox();
            this.B2SUMR = new System.Windows.Forms.CheckBox();
            this.B1SUMR = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.pictureBox18 = new System.Windows.Forms.PictureBox();
            this.pictureBox19 = new System.Windows.Forms.PictureBox();
            this.pictureBox20 = new System.Windows.Forms.PictureBox();
            this.pictureBox21 = new System.Windows.Forms.PictureBox();
            this.pictureBox22 = new System.Windows.Forms.PictureBox();
            this.bitWyj16 = new System.Windows.Forms.CheckBox();
            this.bitWyj8 = new System.Windows.Forms.CheckBox();
            this.bitWyj4 = new System.Windows.Forms.CheckBox();
            this.bitWyj2 = new System.Windows.Forms.CheckBox();
            this.bitWyj1 = new System.Windows.Forms.CheckBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.XORgate = new System.Windows.Forms.PictureBox();
            this.bitWyjOFL = new System.Windows.Forms.CheckBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.A0SUMR = new System.Windows.Forms.CheckBox();
            this.A1SUMR = new System.Windows.Forms.CheckBox();
            this.A2SUMR = new System.Windows.Forms.CheckBox();
            this.A3SUMR = new System.Windows.Forms.CheckBox();
            this.label20 = new System.Windows.Forms.Label();
            this.b1XOR = new System.Windows.Forms.Label();
            this.b2XOR = new System.Windows.Forms.Label();
            this.b3XOR = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.C0SUM = new System.Windows.Forms.CheckBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.BB0SUMR = new System.Windows.Forms.CheckBox();
            this.BB1SUMR = new System.Windows.Forms.CheckBox();
            this.BB2SUMR = new System.Windows.Forms.CheckBox();
            this.BB3SUMR = new System.Windows.Forms.CheckBox();
            this.C03SUMR = new System.Windows.Forms.CheckBox();
            this.FA1Bi = new System.Windows.Forms.CheckBox();
            this.FA1Ai = new System.Windows.Forms.CheckBox();
            this.FA1Si = new System.Windows.Forms.CheckBox();
            this.FA1Ci = new System.Windows.Forms.CheckBox();
            this.FA1CI1 = new System.Windows.Forms.CheckBox();
            this.FA2Ci = new System.Windows.Forms.CheckBox();
            this.FA2Bi = new System.Windows.Forms.CheckBox();
            this.FA2Ai = new System.Windows.Forms.CheckBox();
            this.FA2Si = new System.Windows.Forms.CheckBox();
            this.FA2CI1 = new System.Windows.Forms.CheckBox();
            this.FA3Ci = new System.Windows.Forms.CheckBox();
            this.FA3Ai = new System.Windows.Forms.CheckBox();
            this.FA3Bi = new System.Windows.Forms.CheckBox();
            this.FA3Si = new System.Windows.Forms.CheckBox();
            this.FA3CI1 = new System.Windows.Forms.CheckBox();
            this.FA4Ci = new System.Windows.Forms.CheckBox();
            this.FA4Bi = new System.Windows.Forms.CheckBox();
            this.FA4Ai = new System.Windows.Forms.CheckBox();
            this.FA4CI1 = new System.Windows.Forms.CheckBox();
            this.FA4Si = new System.Windows.Forms.CheckBox();
            this.oflKorektor = new System.Windows.Forms.CheckBox();
            this.cnKorektor = new System.Windows.Forms.CheckBox();
            this.Cn1Korektor = new System.Windows.Forms.CheckBox();
            this.KorektorBit = new System.Windows.Forms.CheckBox();
            this.B0SUMR = new System.Windows.Forms.CheckBox();
            this.pictureBox17 = new System.Windows.Forms.PictureBox();
            this.pictureBox23 = new System.Windows.Forms.PictureBox();
            this.pictureBox24 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.C0SUMXOR)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.XORgate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox24)).BeginInit();
            this.SuspendLayout();
            // 
            // Ai1
            // 
            this.Ai1.AutoSize = true;
            this.Ai1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Ai1.Location = new System.Drawing.Point(23, 25);
            this.Ai1.Name = "Ai1";
            this.Ai1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Ai1.Size = new System.Drawing.Size(37, 19);
            this.Ai1.TabIndex = 0;
            this.Ai1.Text = "Ai";
            this.Ai1.UseVisualStyleBackColor = true;
            this.Ai1.CheckedChanged += new System.EventHandler(this.Ai1_CheckedChanged);
            // 
            // Bi2
            // 
            this.Bi2.AutoSize = true;
            this.Bi2.Location = new System.Drawing.Point(25, 58);
            this.Bi2.Name = "Bi2";
            this.Bi2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Bi2.Size = new System.Drawing.Size(36, 19);
            this.Bi2.TabIndex = 1;
            this.Bi2.Text = "Bi";
            this.Bi2.UseVisualStyleBackColor = true;
            this.Bi2.CheckedChanged += new System.EventHandler(this.Bi2_CheckedChanged);
            // 
            // Ci3
            // 
            this.Ci3.AutoSize = true;
            this.Ci3.Location = new System.Drawing.Point(24, 79);
            this.Ci3.Name = "Ci3";
            this.Ci3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Ci3.Size = new System.Drawing.Size(37, 19);
            this.Ci3.TabIndex = 2;
            this.Ci3.Text = "Ci";
            this.Ci3.UseVisualStyleBackColor = true;
            this.Ci3.CheckedChanged += new System.EventHandler(this.Ci3_CheckedChanged);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.ImageLocation = "";
            this.pictureBox1.Location = new System.Drawing.Point(139, 18);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(104, 63);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.ImageLocation = "";
            this.pictureBox2.Location = new System.Drawing.Point(346, 40);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(104, 63);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 5;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(143, 122);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(82, 43);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 6;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(143, 183);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(82, 43);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 7;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(143, 242);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(82, 43);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 8;
            this.pictureBox5.TabStop = false;
            // 
            // Si1
            // 
            this.Si1.AutoSize = true;
            this.Si1.Location = new System.Drawing.Point(520, 62);
            this.Si1.Name = "Si1";
            this.Si1.Size = new System.Drawing.Size(35, 19);
            this.Si1.TabIndex = 10;
            this.Si1.Text = "Si";
            this.Si1.UseVisualStyleBackColor = true;
            this.Si1.CheckedChanged += new System.EventHandler(this.SiCheckBox_CheckedChanged);
            // 
            // Ci
            // 
            this.Ci.AutoSize = true;
            this.Ci.Location = new System.Drawing.Point(520, 195);
            this.Ci.Name = "Ci";
            this.Ci.Size = new System.Drawing.Size(60, 19);
            this.Ci.TabIndex = 11;
            this.Ci.Text = "Ci  + 1";
            this.Ci.UseVisualStyleBackColor = true;
            this.Ci.CheckedChanged += new System.EventHandler(this.CiCheckBox_CheckedChanged);
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(337, 183);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(86, 43);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6.TabIndex = 12;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox7.Image")));
            this.pictureBox7.Location = new System.Drawing.Point(616, 62);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(111, 88);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox7.TabIndex = 13;
            this.pictureBox7.TabStop = false;
            // 
            // C0
            // 
            this.C0.AutoSize = true;
            this.C0.ForeColor = System.Drawing.SystemColors.ControlText;
            this.C0.Location = new System.Drawing.Point(25, 371);
            this.C0.Name = "C0";
            this.C0.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.C0.Size = new System.Drawing.Size(40, 19);
            this.C0.TabIndex = 14;
            this.C0.Text = "C0";
            this.C0.UseVisualStyleBackColor = true;
            this.C0.CheckedChanged += new System.EventHandler(this.C0_CheckedChanged);
            // 
            // b0
            // 
            this.b0.AutoSize = true;
            this.b0.ForeColor = System.Drawing.SystemColors.ControlText;
            this.b0.Location = new System.Drawing.Point(26, 418);
            this.b0.Name = "b0";
            this.b0.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.b0.Size = new System.Drawing.Size(39, 19);
            this.b0.TabIndex = 15;
            this.b0.Text = "b0";
            this.b0.UseVisualStyleBackColor = true;
            this.b0.CheckedChanged += new System.EventHandler(this.b0_CheckedChanged_1);
            // 
            // b1
            // 
            this.b1.AutoSize = true;
            this.b1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.b1.Location = new System.Drawing.Point(26, 443);
            this.b1.Name = "b1";
            this.b1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.b1.Size = new System.Drawing.Size(39, 19);
            this.b1.TabIndex = 16;
            this.b1.Text = "b1";
            this.b1.UseVisualStyleBackColor = true;
            this.b1.CheckedChanged += new System.EventHandler(this.b1_CheckedChanged);
            // 
            // b2
            // 
            this.b2.AutoSize = true;
            this.b2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.b2.Location = new System.Drawing.Point(26, 469);
            this.b2.Name = "b2";
            this.b2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.b2.Size = new System.Drawing.Size(39, 19);
            this.b2.TabIndex = 17;
            this.b2.Text = "b2";
            this.b2.UseVisualStyleBackColor = true;
            this.b2.CheckedChanged += new System.EventHandler(this.b2_CheckedChanged);
            // 
            // b3
            // 
            this.b3.AutoSize = true;
            this.b3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.b3.Location = new System.Drawing.Point(26, 494);
            this.b3.Name = "b3";
            this.b3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.b3.Size = new System.Drawing.Size(39, 19);
            this.b3.TabIndex = 18;
            this.b3.Text = "b3";
            this.b3.UseVisualStyleBackColor = true;
            this.b3.CheckedChanged += new System.EventHandler(this.b3_CheckedChanged);
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox8.Image")));
            this.pictureBox8.ImageLocation = "";
            this.pictureBox8.Location = new System.Drawing.Point(261, 348);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(73, 40);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox8.TabIndex = 19;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox9.Image")));
            this.pictureBox9.ImageLocation = "";
            this.pictureBox9.Location = new System.Drawing.Point(261, 397);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(73, 40);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox9.TabIndex = 20;
            this.pictureBox9.TabStop = false;
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox10.Image")));
            this.pictureBox10.ImageLocation = "";
            this.pictureBox10.Location = new System.Drawing.Point(261, 447);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(73, 40);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox10.TabIndex = 21;
            this.pictureBox10.TabStop = false;
            // 
            // pictureBox11
            // 
            this.pictureBox11.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox11.Image")));
            this.pictureBox11.ImageLocation = "";
            this.pictureBox11.Location = new System.Drawing.Point(261, 496);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(73, 40);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox11.TabIndex = 22;
            this.pictureBox11.TabStop = false;
            // 
            // b0wyj
            // 
            this.b0wyj.AutoSize = true;
            this.b0wyj.Location = new System.Drawing.Point(500, 358);
            this.b0wyj.Name = "b0wyj";
            this.b0wyj.Size = new System.Drawing.Size(39, 19);
            this.b0wyj.TabIndex = 23;
            this.b0wyj.Text = "B0";
            this.b0wyj.UseVisualStyleBackColor = true;
            // 
            // b1wyj
            // 
            this.b1wyj.AutoSize = true;
            this.b1wyj.Location = new System.Drawing.Point(500, 408);
            this.b1wyj.Name = "b1wyj";
            this.b1wyj.Size = new System.Drawing.Size(39, 19);
            this.b1wyj.TabIndex = 24;
            this.b1wyj.Text = "B1";
            this.b1wyj.UseVisualStyleBackColor = true;
            // 
            // b2wyj
            // 
            this.b2wyj.AutoSize = true;
            this.b2wyj.Location = new System.Drawing.Point(500, 457);
            this.b2wyj.Name = "b2wyj";
            this.b2wyj.Size = new System.Drawing.Size(39, 19);
            this.b2wyj.TabIndex = 25;
            this.b2wyj.Text = "B2";
            this.b2wyj.UseVisualStyleBackColor = true;
            // 
            // b3wyj
            // 
            this.b3wyj.AutoSize = true;
            this.b3wyj.Location = new System.Drawing.Point(500, 506);
            this.b3wyj.Name = "b3wyj";
            this.b3wyj.Size = new System.Drawing.Size(39, 19);
            this.b3wyj.TabIndex = 26;
            this.b3wyj.Text = "B3";
            this.b3wyj.UseVisualStyleBackColor = true;
            // 
            // pictureBox12
            // 
            this.pictureBox12.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox12.Image")));
            this.pictureBox12.Location = new System.Drawing.Point(616, 390);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(117, 72);
            this.pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox12.TabIndex = 27;
            this.pictureBox12.TabStop = false;
            // 
            // CnMinus1
            // 
            this.CnMinus1.AutoSize = true;
            this.CnMinus1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.CnMinus1.Location = new System.Drawing.Point(11, 626);
            this.CnMinus1.Name = "CnMinus1";
            this.CnMinus1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.CnMinus1.Size = new System.Drawing.Size(55, 19);
            this.CnMinus1.TabIndex = 28;
            this.CnMinus1.Text = "Cn -1";
            this.CnMinus1.UseVisualStyleBackColor = true;
            this.CnMinus1.CheckedChanged += new System.EventHandler(this.CnMinus1_CheckedChanged);
            // 
            // Cn
            // 
            this.Cn.AutoSize = true;
            this.Cn.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Cn.Location = new System.Drawing.Point(24, 663);
            this.Cn.Name = "Cn";
            this.Cn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Cn.Size = new System.Drawing.Size(41, 19);
            this.Cn.TabIndex = 29;
            this.Cn.Text = "Cn";
            this.Cn.UseVisualStyleBackColor = true;
            this.Cn.CheckedChanged += new System.EventHandler(this.Cn_CheckedChanged);
            // 
            // Ofl
            // 
            this.Ofl.AutoSize = true;
            this.Ofl.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Ofl.Location = new System.Drawing.Point(23, 697);
            this.Ofl.Name = "Ofl";
            this.Ofl.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Ofl.Size = new System.Drawing.Size(42, 19);
            this.Ofl.TabIndex = 30;
            this.Ofl.Text = "Ofl";
            this.Ofl.UseVisualStyleBackColor = true;
            this.Ofl.CheckedChanged += new System.EventHandler(this.Ofl_CheckedChanged);
            // 
            // piatyBit
            // 
            this.piatyBit.AutoSize = true;
            this.piatyBit.ForeColor = System.Drawing.SystemColors.ControlText;
            this.piatyBit.Location = new System.Drawing.Point(503, 662);
            this.piatyBit.Name = "piatyBit";
            this.piatyBit.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.piatyBit.Size = new System.Drawing.Size(46, 19);
            this.piatyBit.TabIndex = 31;
            this.piatyBit.Text = "5bit";
            this.piatyBit.UseVisualStyleBackColor = true;
            this.piatyBit.CheckedChanged += new System.EventHandler(this.piatyBit_CheckedChanged);
            // 
            // pictureBox13
            // 
            this.pictureBox13.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox13.Image")));
            this.pictureBox13.ImageLocation = "";
            this.pictureBox13.Location = new System.Drawing.Point(160, 628);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(73, 40);
            this.pictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox13.TabIndex = 32;
            this.pictureBox13.TabStop = false;
            // 
            // pictureBox14
            // 
            this.pictureBox14.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox14.Image")));
            this.pictureBox14.Location = new System.Drawing.Point(267, 667);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(82, 43);
            this.pictureBox14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox14.TabIndex = 33;
            this.pictureBox14.TabStop = false;
            // 
            // pictureBox15
            // 
            this.pictureBox15.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox15.Image")));
            this.pictureBox15.Location = new System.Drawing.Point(374, 645);
            this.pictureBox15.Name = "pictureBox15";
            this.pictureBox15.Size = new System.Drawing.Size(103, 53);
            this.pictureBox15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox15.TabIndex = 34;
            this.pictureBox15.TabStop = false;
            // 
            // pictureBox16
            // 
            this.pictureBox16.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox16.Image")));
            this.pictureBox16.Location = new System.Drawing.Point(629, 637);
            this.pictureBox16.Name = "pictureBox16";
            this.pictureBox16.Size = new System.Drawing.Size(71, 73);
            this.pictureBox16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox16.TabIndex = 35;
            this.pictureBox16.TabStop = false;
            // 
            // C0SUMXOR
            // 
            this.C0SUMXOR.Image = ((System.Drawing.Image)(resources.GetObject("C0SUMXOR.Image")));
            this.C0SUMXOR.Location = new System.Drawing.Point(1456, 93);
            this.C0SUMXOR.Name = "C0SUMXOR";
            this.C0SUMXOR.Size = new System.Drawing.Size(100, 46);
            this.C0SUMXOR.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.C0SUMXOR.TabIndex = 36;
            this.C0SUMXOR.TabStop = false;
            // 
            // B3SUMR
            // 
            this.B3SUMR.AutoSize = true;
            this.B3SUMR.Location = new System.Drawing.Point(1526, 50);
            this.B3SUMR.Name = "B3SUMR";
            this.B3SUMR.Size = new System.Drawing.Size(15, 14);
            this.B3SUMR.TabIndex = 37;
            this.B3SUMR.UseVisualStyleBackColor = true;
            this.B3SUMR.CheckedChanged += new System.EventHandler(this.B3SUMR_CheckedChanged);
            // 
            // B2SUMR
            // 
            this.B2SUMR.AutoSize = true;
            this.B2SUMR.Location = new System.Drawing.Point(1506, 50);
            this.B2SUMR.Name = "B2SUMR";
            this.B2SUMR.Size = new System.Drawing.Size(15, 14);
            this.B2SUMR.TabIndex = 38;
            this.B2SUMR.UseVisualStyleBackColor = true;
            this.B2SUMR.CheckedChanged += new System.EventHandler(this.B2SUMR_CheckedChanged);
            // 
            // B1SUMR
            // 
            this.B1SUMR.AutoSize = true;
            this.B1SUMR.Location = new System.Drawing.Point(1485, 50);
            this.B1SUMR.Name = "B1SUMR";
            this.B1SUMR.Size = new System.Drawing.Size(15, 14);
            this.B1SUMR.TabIndex = 39;
            this.B1SUMR.UseVisualStyleBackColor = true;
            this.B1SUMR.CheckedChanged += new System.EventHandler(this.B1SUMR_CheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(1494, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(14, 15);
            this.label1.TabIndex = 41;
            this.label1.Text = "B";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(1467, 10);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(13, 15);
            this.label2.TabIndex = 42;
            this.label2.Text = "8";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(1487, 10);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(13, 15);
            this.label3.TabIndex = 43;
            this.label3.Text = "4";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(1508, 10);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(13, 15);
            this.label4.TabIndex = 44;
            this.label4.Text = "2";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(1529, 10);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(13, 15);
            this.label5.TabIndex = 45;
            this.label5.Text = "1";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(1439, 10);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(25, 15);
            this.label6.TabIndex = 46;
            this.label6.Text = "+/-";
            // 
            // pictureBox18
            // 
            this.pictureBox18.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox18.Image")));
            this.pictureBox18.Location = new System.Drawing.Point(1598, 331);
            this.pictureBox18.Name = "pictureBox18";
            this.pictureBox18.Size = new System.Drawing.Size(69, 59);
            this.pictureBox18.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox18.TabIndex = 47;
            this.pictureBox18.TabStop = false;
            // 
            // pictureBox19
            // 
            this.pictureBox19.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox19.Image")));
            this.pictureBox19.Location = new System.Drawing.Point(1450, 331);
            this.pictureBox19.Name = "pictureBox19";
            this.pictureBox19.Size = new System.Drawing.Size(69, 59);
            this.pictureBox19.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox19.TabIndex = 48;
            this.pictureBox19.TabStop = false;
            // 
            // pictureBox20
            // 
            this.pictureBox20.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox20.Image")));
            this.pictureBox20.Location = new System.Drawing.Point(1308, 331);
            this.pictureBox20.Name = "pictureBox20";
            this.pictureBox20.Size = new System.Drawing.Size(69, 59);
            this.pictureBox20.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox20.TabIndex = 49;
            this.pictureBox20.TabStop = false;
            // 
            // pictureBox21
            // 
            this.pictureBox21.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox21.Image")));
            this.pictureBox21.Location = new System.Drawing.Point(1160, 331);
            this.pictureBox21.Name = "pictureBox21";
            this.pictureBox21.Size = new System.Drawing.Size(69, 59);
            this.pictureBox21.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox21.TabIndex = 50;
            this.pictureBox21.TabStop = false;
            // 
            // pictureBox22
            // 
            this.pictureBox22.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox22.Image")));
            this.pictureBox22.Location = new System.Drawing.Point(1362, 645);
            this.pictureBox22.Name = "pictureBox22";
            this.pictureBox22.Size = new System.Drawing.Size(71, 39);
            this.pictureBox22.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox22.TabIndex = 51;
            this.pictureBox22.TabStop = false;
            // 
            // bitWyj16
            // 
            this.bitWyj16.AutoSize = true;
            this.bitWyj16.Location = new System.Drawing.Point(1391, 761);
            this.bitWyj16.Name = "bitWyj16";
            this.bitWyj16.Size = new System.Drawing.Size(15, 14);
            this.bitWyj16.TabIndex = 52;
            this.bitWyj16.UseVisualStyleBackColor = true;
            this.bitWyj16.CheckedChanged += new System.EventHandler(this.bitWyj16_CheckedChanged);
            // 
            // bitWyj8
            // 
            this.bitWyj8.AutoSize = true;
            this.bitWyj8.Location = new System.Drawing.Point(1437, 761);
            this.bitWyj8.Name = "bitWyj8";
            this.bitWyj8.Size = new System.Drawing.Size(15, 14);
            this.bitWyj8.TabIndex = 53;
            this.bitWyj8.UseVisualStyleBackColor = true;
            this.bitWyj8.CheckedChanged += new System.EventHandler(this.bitWyj8_CheckedChanged);
            // 
            // bitWyj4
            // 
            this.bitWyj4.AutoSize = true;
            this.bitWyj4.Location = new System.Drawing.Point(1458, 761);
            this.bitWyj4.Name = "bitWyj4";
            this.bitWyj4.Size = new System.Drawing.Size(15, 14);
            this.bitWyj4.TabIndex = 54;
            this.bitWyj4.UseVisualStyleBackColor = true;
            this.bitWyj4.CheckedChanged += new System.EventHandler(this.bitWyj4_CheckedChanged);
            // 
            // bitWyj2
            // 
            this.bitWyj2.AutoSize = true;
            this.bitWyj2.Location = new System.Drawing.Point(1479, 761);
            this.bitWyj2.Name = "bitWyj2";
            this.bitWyj2.Size = new System.Drawing.Size(15, 14);
            this.bitWyj2.TabIndex = 55;
            this.bitWyj2.UseVisualStyleBackColor = true;
            this.bitWyj2.CheckedChanged += new System.EventHandler(this.bitWyj2_CheckedChanged);
            // 
            // bitWyj1
            // 
            this.bitWyj1.AutoSize = true;
            this.bitWyj1.Location = new System.Drawing.Point(1500, 761);
            this.bitWyj1.Name = "bitWyj1";
            this.bitWyj1.Size = new System.Drawing.Size(15, 14);
            this.bitWyj1.TabIndex = 56;
            this.bitWyj1.UseVisualStyleBackColor = true;
            this.bitWyj1.CheckedChanged += new System.EventHandler(this.bitWyj1_CheckedChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(1500, 787);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(13, 15);
            this.label7.TabIndex = 57;
            this.label7.Text = "1";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(1479, 787);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(13, 15);
            this.label8.TabIndex = 58;
            this.label8.Text = "2";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(1458, 787);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(13, 15);
            this.label9.TabIndex = 59;
            this.label9.Text = "4";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(1437, 787);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(13, 15);
            this.label10.TabIndex = 60;
            this.label10.Text = "8";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(1391, 787);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(19, 15);
            this.label11.TabIndex = 61;
            this.label11.Text = "16";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(1360, 787);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(25, 15);
            this.label12.TabIndex = 62;
            this.label12.Text = "+/-";
            // 
            // XORgate
            // 
            this.XORgate.Image = ((System.Drawing.Image)(resources.GetObject("XORgate.Image")));
            this.XORgate.ImageLocation = "";
            this.XORgate.Location = new System.Drawing.Point(1076, 565);
            this.XORgate.Name = "XORgate";
            this.XORgate.Size = new System.Drawing.Size(45, 80);
            this.XORgate.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.XORgate.TabIndex = 63;
            this.XORgate.TabStop = false;
            // 
            // bitWyjOFL
            // 
            this.bitWyjOFL.AutoSize = true;
            this.bitWyjOFL.Location = new System.Drawing.Point(1091, 727);
            this.bitWyjOFL.Name = "bitWyjOFL";
            this.bitWyjOFL.Size = new System.Drawing.Size(15, 14);
            this.bitWyjOFL.TabIndex = 64;
            this.bitWyjOFL.UseVisualStyleBackColor = true;
            this.bitWyjOFL.CheckedChanged += new System.EventHandler(this.bitWyjOFL_CheckedChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(1083, 746);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(28, 15);
            this.label13.TabIndex = 65;
            this.label13.Text = "OFL";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(1254, 10);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(25, 15);
            this.label14.TabIndex = 75;
            this.label14.Text = "+/-";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(1343, 10);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(13, 15);
            this.label15.TabIndex = 74;
            this.label15.Text = "1";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(1322, 10);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(13, 15);
            this.label16.TabIndex = 73;
            this.label16.Text = "2";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(1302, 10);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(13, 15);
            this.label17.TabIndex = 72;
            this.label17.Text = "4";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(1282, 10);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(13, 15);
            this.label18.TabIndex = 71;
            this.label18.Text = "8";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(1309, 29);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(15, 15);
            this.label19.TabIndex = 70;
            this.label19.Text = "A";
            // 
            // A0SUMR
            // 
            this.A0SUMR.AutoSize = true;
            this.A0SUMR.Location = new System.Drawing.Point(1280, 50);
            this.A0SUMR.Name = "A0SUMR";
            this.A0SUMR.Size = new System.Drawing.Size(15, 14);
            this.A0SUMR.TabIndex = 69;
            this.A0SUMR.UseVisualStyleBackColor = true;
            this.A0SUMR.CheckedChanged += new System.EventHandler(this.A0SUMR_CheckedChanged);
            // 
            // A1SUMR
            // 
            this.A1SUMR.AutoSize = true;
            this.A1SUMR.Location = new System.Drawing.Point(1300, 50);
            this.A1SUMR.Name = "A1SUMR";
            this.A1SUMR.Size = new System.Drawing.Size(15, 14);
            this.A1SUMR.TabIndex = 68;
            this.A1SUMR.UseVisualStyleBackColor = true;
            this.A1SUMR.CheckedChanged += new System.EventHandler(this.A1SUMR_CheckedChanged);
            // 
            // A2SUMR
            // 
            this.A2SUMR.AutoSize = true;
            this.A2SUMR.Location = new System.Drawing.Point(1319, 50);
            this.A2SUMR.Name = "A2SUMR";
            this.A2SUMR.Size = new System.Drawing.Size(15, 14);
            this.A2SUMR.TabIndex = 67;
            this.A2SUMR.UseVisualStyleBackColor = true;
            this.A2SUMR.CheckedChanged += new System.EventHandler(this.A2SUMR_CheckedChanged);
            // 
            // A3SUMR
            // 
            this.A3SUMR.AutoSize = true;
            this.A3SUMR.Location = new System.Drawing.Point(1339, 50);
            this.A3SUMR.Name = "A3SUMR";
            this.A3SUMR.Size = new System.Drawing.Size(15, 14);
            this.A3SUMR.TabIndex = 66;
            this.A3SUMR.UseVisualStyleBackColor = true;
            this.A3SUMR.CheckedChanged += new System.EventHandler(this.A3SUMR_CheckedChanged);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(1462, 75);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(20, 15);
            this.label20.TabIndex = 76;
            this.label20.Text = "b0";
            // 
            // b1XOR
            // 
            this.b1XOR.AutoSize = true;
            this.b1XOR.Location = new System.Drawing.Point(1481, 75);
            this.b1XOR.Name = "b1XOR";
            this.b1XOR.Size = new System.Drawing.Size(20, 15);
            this.b1XOR.TabIndex = 77;
            this.b1XOR.Text = "b1";
            // 
            // b2XOR
            // 
            this.b2XOR.AutoSize = true;
            this.b2XOR.Location = new System.Drawing.Point(1503, 75);
            this.b2XOR.Name = "b2XOR";
            this.b2XOR.Size = new System.Drawing.Size(20, 15);
            this.b2XOR.TabIndex = 78;
            this.b2XOR.Text = "b2";
            // 
            // b3XOR
            // 
            this.b3XOR.AutoSize = true;
            this.b3XOR.Location = new System.Drawing.Point(1521, 75);
            this.b3XOR.Name = "b3XOR";
            this.b3XOR.Size = new System.Drawing.Size(20, 15);
            this.b3XOR.TabIndex = 79;
            this.b3XOR.Text = "b3";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(1555, 109);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(21, 15);
            this.label24.TabIndex = 80;
            this.label24.Text = "C0";
            // 
            // C0SUM
            // 
            this.C0SUM.AutoSize = true;
            this.C0SUM.Location = new System.Drawing.Point(1733, 354);
            this.C0SUM.Name = "C0SUM";
            this.C0SUM.Size = new System.Drawing.Size(15, 14);
            this.C0SUM.TabIndex = 81;
            this.C0SUM.UseVisualStyleBackColor = true;
            this.C0SUM.CheckedChanged += new System.EventHandler(this.C0SUM_CheckedChanged);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(1729, 332);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(21, 15);
            this.label21.TabIndex = 82;
            this.label21.Text = "C0";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(1522, 142);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(20, 15);
            this.label22.TabIndex = 86;
            this.label22.Text = "B3";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(1502, 142);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(20, 15);
            this.label23.TabIndex = 85;
            this.label23.Text = "B2";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(1483, 142);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(20, 15);
            this.label25.TabIndex = 84;
            this.label25.Text = "B1";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(1462, 142);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(20, 15);
            this.label26.TabIndex = 83;
            this.label26.Text = "B0";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(1610, 313);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(18, 15);
            this.label27.TabIndex = 87;
            this.label27.Text = "Ai";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(1641, 313);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(17, 15);
            this.label28.TabIndex = 88;
            this.label28.Text = "Bi";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(1670, 353);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(18, 15);
            this.label29.TabIndex = 89;
            this.label29.Text = "Ci";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(1624, 393);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(16, 15);
            this.label30.TabIndex = 90;
            this.label30.Text = "Si";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(1562, 353);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(32, 15);
            this.label31.TabIndex = 91;
            this.label31.Text = "Ci+1";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(1416, 353);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(32, 15);
            this.label32.TabIndex = 96;
            this.label32.Text = "Ci+1";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(1478, 393);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(16, 15);
            this.label33.TabIndex = 95;
            this.label33.Text = "Si";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(1524, 353);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(18, 15);
            this.label34.TabIndex = 94;
            this.label34.Text = "Ci";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(1494, 313);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(17, 15);
            this.label35.TabIndex = 93;
            this.label35.Text = "Bi";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(1463, 313);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(18, 15);
            this.label36.TabIndex = 92;
            this.label36.Text = "Ai";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(1273, 353);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(32, 15);
            this.label37.TabIndex = 101;
            this.label37.Text = "Ci+1";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(1335, 393);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(16, 15);
            this.label38.TabIndex = 100;
            this.label38.Text = "Si";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(1382, 353);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(18, 15);
            this.label39.TabIndex = 99;
            this.label39.Text = "Ci";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(1351, 313);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(17, 15);
            this.label40.TabIndex = 98;
            this.label40.Text = "Bi";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(1320, 312);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(18, 15);
            this.label41.TabIndex = 97;
            this.label41.Text = "Ai";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(1123, 353);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(32, 15);
            this.label42.TabIndex = 106;
            this.label42.Text = "Ci+1";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(1185, 393);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(16, 15);
            this.label43.TabIndex = 105;
            this.label43.Text = "Si";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(1231, 353);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(18, 15);
            this.label44.TabIndex = 104;
            this.label44.Text = "Ci";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(1202, 313);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(17, 15);
            this.label45.TabIndex = 103;
            this.label45.Text = "Bi";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(1171, 313);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(18, 15);
            this.label46.TabIndex = 102;
            this.label46.Text = "Ai";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(1366, 626);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(21, 15);
            this.label47.TabIndex = 107;
            this.label47.Text = "ofl";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(1387, 626);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(20, 15);
            this.label48.TabIndex = 108;
            this.label48.Text = "cn";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(1405, 626);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(31, 15);
            this.label49.TabIndex = 109;
            this.label49.Text = "cn-1";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(1385, 687);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(27, 15);
            this.label50.TabIndex = 110;
            this.label50.Text = "5bit";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(1774, 342);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(82, 15);
            this.label51.TabIndex = 111;
            this.label51.Text = "0 - dodawanie";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(1774, 365);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(96, 15);
            this.label52.TabIndex = 112;
            this.label52.Text = "1 - odejmowanie";
            // 
            // BB0SUMR
            // 
            this.BB0SUMR.AutoSize = true;
            this.BB0SUMR.Location = new System.Drawing.Point(1467, 125);
            this.BB0SUMR.Name = "BB0SUMR";
            this.BB0SUMR.Size = new System.Drawing.Size(15, 14);
            this.BB0SUMR.TabIndex = 113;
            this.BB0SUMR.UseVisualStyleBackColor = true;
            this.BB0SUMR.CheckedChanged += new System.EventHandler(this.BB0SUMR_CheckedChanged);
            // 
            // BB1SUMR
            // 
            this.BB1SUMR.AutoSize = true;
            this.BB1SUMR.Location = new System.Drawing.Point(1485, 125);
            this.BB1SUMR.Name = "BB1SUMR";
            this.BB1SUMR.Size = new System.Drawing.Size(15, 14);
            this.BB1SUMR.TabIndex = 114;
            this.BB1SUMR.UseVisualStyleBackColor = true;
            this.BB1SUMR.CheckedChanged += new System.EventHandler(this.BB1SUMR_CheckedChanged);
            // 
            // BB2SUMR
            // 
            this.BB2SUMR.AutoSize = true;
            this.BB2SUMR.Location = new System.Drawing.Point(1506, 125);
            this.BB2SUMR.Name = "BB2SUMR";
            this.BB2SUMR.Size = new System.Drawing.Size(15, 14);
            this.BB2SUMR.TabIndex = 115;
            this.BB2SUMR.UseVisualStyleBackColor = true;
            this.BB2SUMR.CheckedChanged += new System.EventHandler(this.BB2SUMR_CheckedChanged);
            // 
            // BB3SUMR
            // 
            this.BB3SUMR.AutoSize = true;
            this.BB3SUMR.Location = new System.Drawing.Point(1526, 125);
            this.BB3SUMR.Name = "BB3SUMR";
            this.BB3SUMR.Size = new System.Drawing.Size(15, 14);
            this.BB3SUMR.TabIndex = 116;
            this.BB3SUMR.UseVisualStyleBackColor = true;
            this.BB3SUMR.CheckedChanged += new System.EventHandler(this.BB3SUMR_CheckedChanged);
            // 
            // C03SUMR
            // 
            this.C03SUMR.AutoSize = true;
            this.C03SUMR.Location = new System.Drawing.Point(1543, 110);
            this.C03SUMR.Name = "C03SUMR";
            this.C03SUMR.Size = new System.Drawing.Size(15, 14);
            this.C03SUMR.TabIndex = 117;
            this.C03SUMR.UseVisualStyleBackColor = true;
            this.C03SUMR.CheckedChanged += new System.EventHandler(this.C03SUMR_CheckedChanged);
            // 
            // FA1Bi
            // 
            this.FA1Bi.AutoSize = true;
            this.FA1Bi.Location = new System.Drawing.Point(1643, 328);
            this.FA1Bi.Name = "FA1Bi";
            this.FA1Bi.Size = new System.Drawing.Size(15, 14);
            this.FA1Bi.TabIndex = 118;
            this.FA1Bi.UseVisualStyleBackColor = true;
            this.FA1Bi.CheckedChanged += new System.EventHandler(this.FA1Bi_CheckedChanged);
            // 
            // FA1Ai
            // 
            this.FA1Ai.AutoSize = true;
            this.FA1Ai.Location = new System.Drawing.Point(1612, 328);
            this.FA1Ai.Name = "FA1Ai";
            this.FA1Ai.Size = new System.Drawing.Size(15, 14);
            this.FA1Ai.TabIndex = 119;
            this.FA1Ai.UseVisualStyleBackColor = true;
            this.FA1Ai.CheckedChanged += new System.EventHandler(this.FA1Ai_CheckedChanged);
            // 
            // FA1Si
            // 
            this.FA1Si.AutoSize = true;
            this.FA1Si.Location = new System.Drawing.Point(1626, 378);
            this.FA1Si.Name = "FA1Si";
            this.FA1Si.Size = new System.Drawing.Size(15, 14);
            this.FA1Si.TabIndex = 120;
            this.FA1Si.UseVisualStyleBackColor = true;
            this.FA1Si.CheckedChanged += new System.EventHandler(this.FA1Si_CheckedChanged);
            // 
            // FA1Ci
            // 
            this.FA1Ci.AutoSize = true;
            this.FA1Ci.Location = new System.Drawing.Point(1656, 352);
            this.FA1Ci.Name = "FA1Ci";
            this.FA1Ci.Size = new System.Drawing.Size(15, 14);
            this.FA1Ci.TabIndex = 121;
            this.FA1Ci.UseVisualStyleBackColor = true;
            this.FA1Ci.CheckedChanged += new System.EventHandler(this.FA1Ci_CheckedChanged);
            // 
            // FA1CI1
            // 
            this.FA1CI1.AutoSize = true;
            this.FA1CI1.Location = new System.Drawing.Point(1596, 354);
            this.FA1CI1.Name = "FA1CI1";
            this.FA1CI1.Size = new System.Drawing.Size(15, 14);
            this.FA1CI1.TabIndex = 122;
            this.FA1CI1.UseVisualStyleBackColor = true;
            this.FA1CI1.CheckedChanged += new System.EventHandler(this.FA1CI1_CheckedChanged);
            // 
            // FA2Ci
            // 
            this.FA2Ci.AutoSize = true;
            this.FA2Ci.Location = new System.Drawing.Point(1508, 353);
            this.FA2Ci.Name = "FA2Ci";
            this.FA2Ci.Size = new System.Drawing.Size(15, 14);
            this.FA2Ci.TabIndex = 123;
            this.FA2Ci.UseVisualStyleBackColor = true;
            this.FA2Ci.CheckedChanged += new System.EventHandler(this.FA2Ci_CheckedChanged);
            // 
            // FA2Bi
            // 
            this.FA2Bi.AutoSize = true;
            this.FA2Bi.Location = new System.Drawing.Point(1494, 328);
            this.FA2Bi.Name = "FA2Bi";
            this.FA2Bi.Size = new System.Drawing.Size(15, 14);
            this.FA2Bi.TabIndex = 124;
            this.FA2Bi.UseVisualStyleBackColor = true;
            this.FA2Bi.CheckedChanged += new System.EventHandler(this.FA2Bi_CheckedChanged);
            // 
            // FA2Ai
            // 
            this.FA2Ai.AutoSize = true;
            this.FA2Ai.Location = new System.Drawing.Point(1463, 328);
            this.FA2Ai.Name = "FA2Ai";
            this.FA2Ai.Size = new System.Drawing.Size(15, 14);
            this.FA2Ai.TabIndex = 125;
            this.FA2Ai.UseVisualStyleBackColor = true;
            this.FA2Ai.CheckedChanged += new System.EventHandler(this.FA2Ai_CheckedChanged);
            // 
            // FA2Si
            // 
            this.FA2Si.AutoSize = true;
            this.FA2Si.Location = new System.Drawing.Point(1479, 378);
            this.FA2Si.Name = "FA2Si";
            this.FA2Si.Size = new System.Drawing.Size(15, 14);
            this.FA2Si.TabIndex = 126;
            this.FA2Si.UseVisualStyleBackColor = true;
            this.FA2Si.CheckedChanged += new System.EventHandler(this.FA2Si_CheckedChanged);
            // 
            // FA2CI1
            // 
            this.FA2CI1.AutoSize = true;
            this.FA2CI1.Location = new System.Drawing.Point(1449, 353);
            this.FA2CI1.Name = "FA2CI1";
            this.FA2CI1.Size = new System.Drawing.Size(15, 14);
            this.FA2CI1.TabIndex = 127;
            this.FA2CI1.UseVisualStyleBackColor = true;
            this.FA2CI1.CheckedChanged += new System.EventHandler(this.FA2CI1_CheckedChanged);
            // 
            // FA3Ci
            // 
            this.FA3Ci.AutoSize = true;
            this.FA3Ci.Location = new System.Drawing.Point(1366, 352);
            this.FA3Ci.Name = "FA3Ci";
            this.FA3Ci.Size = new System.Drawing.Size(15, 14);
            this.FA3Ci.TabIndex = 128;
            this.FA3Ci.UseVisualStyleBackColor = true;
            this.FA3Ci.CheckedChanged += new System.EventHandler(this.FA3Ci_CheckedChanged);
            // 
            // FA3Ai
            // 
            this.FA3Ai.AutoSize = true;
            this.FA3Ai.Location = new System.Drawing.Point(1322, 328);
            this.FA3Ai.Name = "FA3Ai";
            this.FA3Ai.Size = new System.Drawing.Size(15, 14);
            this.FA3Ai.TabIndex = 129;
            this.FA3Ai.UseVisualStyleBackColor = true;
            // 
            // FA3Bi
            // 
            this.FA3Bi.AutoSize = true;
            this.FA3Bi.Location = new System.Drawing.Point(1353, 328);
            this.FA3Bi.Name = "FA3Bi";
            this.FA3Bi.Size = new System.Drawing.Size(15, 14);
            this.FA3Bi.TabIndex = 130;
            this.FA3Bi.UseVisualStyleBackColor = true;
            // 
            // FA3Si
            // 
            this.FA3Si.AutoSize = true;
            this.FA3Si.Location = new System.Drawing.Point(1336, 378);
            this.FA3Si.Name = "FA3Si";
            this.FA3Si.Size = new System.Drawing.Size(15, 14);
            this.FA3Si.TabIndex = 131;
            this.FA3Si.UseVisualStyleBackColor = true;
            // 
            // FA3CI1
            // 
            this.FA3CI1.AutoSize = true;
            this.FA3CI1.Location = new System.Drawing.Point(1308, 353);
            this.FA3CI1.Name = "FA3CI1";
            this.FA3CI1.Size = new System.Drawing.Size(15, 14);
            this.FA3CI1.TabIndex = 132;
            this.FA3CI1.UseVisualStyleBackColor = true;
            // 
            // FA4Ci
            // 
            this.FA4Ci.AutoSize = true;
            this.FA4Ci.Location = new System.Drawing.Point(1214, 353);
            this.FA4Ci.Name = "FA4Ci";
            this.FA4Ci.Size = new System.Drawing.Size(15, 14);
            this.FA4Ci.TabIndex = 133;
            this.FA4Ci.UseVisualStyleBackColor = true;
            // 
            // FA4Bi
            // 
            this.FA4Bi.AutoSize = true;
            this.FA4Bi.Location = new System.Drawing.Point(1202, 328);
            this.FA4Bi.Name = "FA4Bi";
            this.FA4Bi.Size = new System.Drawing.Size(15, 14);
            this.FA4Bi.TabIndex = 134;
            this.FA4Bi.UseVisualStyleBackColor = true;
            // 
            // FA4Ai
            // 
            this.FA4Ai.AutoSize = true;
            this.FA4Ai.Location = new System.Drawing.Point(1174, 328);
            this.FA4Ai.Name = "FA4Ai";
            this.FA4Ai.Size = new System.Drawing.Size(15, 14);
            this.FA4Ai.TabIndex = 135;
            this.FA4Ai.UseVisualStyleBackColor = true;
            // 
            // FA4CI1
            // 
            this.FA4CI1.AutoSize = true;
            this.FA4CI1.Location = new System.Drawing.Point(1160, 353);
            this.FA4CI1.Name = "FA4CI1";
            this.FA4CI1.Size = new System.Drawing.Size(15, 14);
            this.FA4CI1.TabIndex = 136;
            this.FA4CI1.UseVisualStyleBackColor = true;
            // 
            // FA4Si
            // 
            this.FA4Si.AutoSize = true;
            this.FA4Si.Location = new System.Drawing.Point(1186, 378);
            this.FA4Si.Name = "FA4Si";
            this.FA4Si.Size = new System.Drawing.Size(15, 14);
            this.FA4Si.TabIndex = 137;
            this.FA4Si.UseVisualStyleBackColor = true;
            // 
            // oflKorektor
            // 
            this.oflKorektor.AutoSize = true;
            this.oflKorektor.Location = new System.Drawing.Point(1372, 644);
            this.oflKorektor.Name = "oflKorektor";
            this.oflKorektor.Size = new System.Drawing.Size(15, 14);
            this.oflKorektor.TabIndex = 138;
            this.oflKorektor.UseVisualStyleBackColor = true;
            // 
            // cnKorektor
            // 
            this.cnKorektor.AutoSize = true;
            this.cnKorektor.Location = new System.Drawing.Point(1392, 644);
            this.cnKorektor.Name = "cnKorektor";
            this.cnKorektor.Size = new System.Drawing.Size(15, 14);
            this.cnKorektor.TabIndex = 139;
            this.cnKorektor.UseVisualStyleBackColor = true;
            // 
            // Cn1Korektor
            // 
            this.Cn1Korektor.AutoSize = true;
            this.Cn1Korektor.Location = new System.Drawing.Point(1413, 644);
            this.Cn1Korektor.Name = "Cn1Korektor";
            this.Cn1Korektor.Size = new System.Drawing.Size(15, 14);
            this.Cn1Korektor.TabIndex = 140;
            this.Cn1Korektor.UseVisualStyleBackColor = true;
            // 
            // KorektorBit
            // 
            this.KorektorBit.AutoSize = true;
            this.KorektorBit.Location = new System.Drawing.Point(1391, 670);
            this.KorektorBit.Name = "KorektorBit";
            this.KorektorBit.Size = new System.Drawing.Size(15, 14);
            this.KorektorBit.TabIndex = 141;
            this.KorektorBit.UseVisualStyleBackColor = true;
            // 
            // B0SUMR
            // 
            this.B0SUMR.AutoSize = true;
            this.B0SUMR.Location = new System.Drawing.Point(1465, 50);
            this.B0SUMR.Name = "B0SUMR";
            this.B0SUMR.Size = new System.Drawing.Size(15, 14);
            this.B0SUMR.TabIndex = 40;
            this.B0SUMR.UseVisualStyleBackColor = true;
            this.B0SUMR.CheckedChanged += new System.EventHandler(this.B0SUMR_CheckedChanged);
            // 
            // pictureBox17
            // 
            this.pictureBox17.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox17.Image")));
            this.pictureBox17.Location = new System.Drawing.Point(1123, 40);
            this.pictureBox17.Name = "pictureBox17";
            this.pictureBox17.Size = new System.Drawing.Size(107, 97);
            this.pictureBox17.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox17.TabIndex = 142;
            this.pictureBox17.TabStop = false;
            this.pictureBox17.WaitOnLoad = true;
            // 
            // pictureBox23
            // 
            this.pictureBox23.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox23.Image")));
            this.pictureBox23.Location = new System.Drawing.Point(1610, 40);
            this.pictureBox23.Name = "pictureBox23";
            this.pictureBox23.Size = new System.Drawing.Size(107, 97);
            this.pictureBox23.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox23.TabIndex = 143;
            this.pictureBox23.TabStop = false;
            this.pictureBox23.WaitOnLoad = true;
            // 
            // pictureBox24
            // 
            this.pictureBox24.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox24.Image")));
            this.pictureBox24.Location = new System.Drawing.Point(1366, 821);
            this.pictureBox24.Name = "pictureBox24";
            this.pictureBox24.Size = new System.Drawing.Size(165, 106);
            this.pictureBox24.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox24.TabIndex = 144;
            this.pictureBox24.TabStop = false;
            this.pictureBox24.WaitOnLoad = true;
            // 
            // SumatorSubtraktor
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1884, 961);
            this.Controls.Add(this.pictureBox24);
            this.Controls.Add(this.pictureBox23);
            this.Controls.Add(this.pictureBox17);
            this.Controls.Add(this.KorektorBit);
            this.Controls.Add(this.Cn1Korektor);
            this.Controls.Add(this.cnKorektor);
            this.Controls.Add(this.oflKorektor);
            this.Controls.Add(this.FA4Si);
            this.Controls.Add(this.FA4CI1);
            this.Controls.Add(this.FA4Ai);
            this.Controls.Add(this.FA4Bi);
            this.Controls.Add(this.FA4Ci);
            this.Controls.Add(this.FA3CI1);
            this.Controls.Add(this.FA3Si);
            this.Controls.Add(this.FA3Bi);
            this.Controls.Add(this.FA3Ai);
            this.Controls.Add(this.FA3Ci);
            this.Controls.Add(this.FA2CI1);
            this.Controls.Add(this.FA2Si);
            this.Controls.Add(this.FA2Ai);
            this.Controls.Add(this.FA2Bi);
            this.Controls.Add(this.FA2Ci);
            this.Controls.Add(this.FA1CI1);
            this.Controls.Add(this.FA1Ci);
            this.Controls.Add(this.FA1Si);
            this.Controls.Add(this.FA1Ai);
            this.Controls.Add(this.FA1Bi);
            this.Controls.Add(this.C03SUMR);
            this.Controls.Add(this.BB3SUMR);
            this.Controls.Add(this.BB2SUMR);
            this.Controls.Add(this.BB1SUMR);
            this.Controls.Add(this.BB0SUMR);
            this.Controls.Add(this.label52);
            this.Controls.Add(this.label51);
            this.Controls.Add(this.label50);
            this.Controls.Add(this.label49);
            this.Controls.Add(this.label48);
            this.Controls.Add(this.label47);
            this.Controls.Add(this.label42);
            this.Controls.Add(this.label43);
            this.Controls.Add(this.label44);
            this.Controls.Add(this.label45);
            this.Controls.Add(this.label46);
            this.Controls.Add(this.label37);
            this.Controls.Add(this.label38);
            this.Controls.Add(this.label39);
            this.Controls.Add(this.label40);
            this.Controls.Add(this.label41);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.label33);
            this.Controls.Add(this.label34);
            this.Controls.Add(this.label35);
            this.Controls.Add(this.label36);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.C0SUM);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.b3XOR);
            this.Controls.Add(this.b2XOR);
            this.Controls.Add(this.b1XOR);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.A0SUMR);
            this.Controls.Add(this.A1SUMR);
            this.Controls.Add(this.A2SUMR);
            this.Controls.Add(this.A3SUMR);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.bitWyjOFL);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.bitWyj1);
            this.Controls.Add(this.bitWyj2);
            this.Controls.Add(this.bitWyj4);
            this.Controls.Add(this.bitWyj8);
            this.Controls.Add(this.bitWyj16);
            this.Controls.Add(this.pictureBox22);
            this.Controls.Add(this.pictureBox21);
            this.Controls.Add(this.pictureBox20);
            this.Controls.Add(this.pictureBox19);
            this.Controls.Add(this.pictureBox18);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.B0SUMR);
            this.Controls.Add(this.B1SUMR);
            this.Controls.Add(this.B2SUMR);
            this.Controls.Add(this.B3SUMR);
            this.Controls.Add(this.C0SUMXOR);
            this.Controls.Add(this.pictureBox16);
            this.Controls.Add(this.pictureBox15);
            this.Controls.Add(this.pictureBox14);
            this.Controls.Add(this.pictureBox13);
            this.Controls.Add(this.piatyBit);
            this.Controls.Add(this.Ofl);
            this.Controls.Add(this.Cn);
            this.Controls.Add(this.CnMinus1);
            this.Controls.Add(this.pictureBox12);
            this.Controls.Add(this.b3wyj);
            this.Controls.Add(this.b2wyj);
            this.Controls.Add(this.b1wyj);
            this.Controls.Add(this.b0wyj);
            this.Controls.Add(this.pictureBox11);
            this.Controls.Add(this.pictureBox10);
            this.Controls.Add(this.pictureBox9);
            this.Controls.Add(this.pictureBox8);
            this.Controls.Add(this.b3);
            this.Controls.Add(this.b2);
            this.Controls.Add(this.b1);
            this.Controls.Add(this.b0);
            this.Controls.Add(this.C0);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.Ci);
            this.Controls.Add(this.Si1);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.Ci3);
            this.Controls.Add(this.Bi2);
            this.Controls.Add(this.Ai1);
            this.Controls.Add(this.XORgate);
            this.Controls.Add(this.label20);
            this.DoubleBuffered = true;
            this.Name = "SumatorSubtraktor";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Sumator/Subtraktor";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.C0SUMXOR)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.XORgate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox24)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox Ai1;
        private System.Windows.Forms.CheckBox Bi2;
        private System.Windows.Forms.CheckBox Ci3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.CheckBox Si1;
        private System.Windows.Forms.CheckBox Ci;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.CheckBox C0;
        private System.Windows.Forms.CheckBox b0;
        private System.Windows.Forms.CheckBox b1;
        private System.Windows.Forms.CheckBox b2;
        private System.Windows.Forms.CheckBox b3;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.CheckBox b0wyj;
        private System.Windows.Forms.CheckBox b1wyj;
        private System.Windows.Forms.CheckBox b2wyj;
        private System.Windows.Forms.CheckBox b3wyj;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.CheckBox CnMinus1;
        private System.Windows.Forms.CheckBox Cn;
        private System.Windows.Forms.CheckBox Ofl;
        private System.Windows.Forms.CheckBox piatyBit;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.PictureBox pictureBox15;
        private System.Windows.Forms.PictureBox pictureBox16;
        private System.Windows.Forms.PictureBox C0SUMXOR;
        private System.Windows.Forms.CheckBox B3SUMR;
        private System.Windows.Forms.CheckBox B2SUMR;
        private System.Windows.Forms.CheckBox B1SUMR;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox pictureBox18;
        private System.Windows.Forms.PictureBox pictureBox19;
        private System.Windows.Forms.PictureBox pictureBox20;
        private System.Windows.Forms.PictureBox pictureBox21;
        private System.Windows.Forms.PictureBox pictureBox22;
        private System.Windows.Forms.CheckBox bitWyj16;
        private System.Windows.Forms.CheckBox bitWyj8;
        private System.Windows.Forms.CheckBox bitWyj4;
        private System.Windows.Forms.CheckBox bitWyj2;
        private System.Windows.Forms.CheckBox bitWyj1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.PictureBox XORgate;
        private System.Windows.Forms.CheckBox bitWyjOFL;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.CheckBox A0SUMR;
        private System.Windows.Forms.CheckBox A1SUMR;
        private System.Windows.Forms.CheckBox A2SUMR;
        private System.Windows.Forms.CheckBox A3SUMR;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label b1XOR;
        private System.Windows.Forms.Label b2XOR;
        private System.Windows.Forms.Label b3XOR;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.CheckBox C0SUM;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.CheckBox BB0SUMR;
        private System.Windows.Forms.CheckBox BB1SUMR;
        private System.Windows.Forms.CheckBox BB2SUMR;
        private System.Windows.Forms.CheckBox BB3SUMR;
        private System.Windows.Forms.CheckBox C03SUMR;
        private System.Windows.Forms.CheckBox FA1Bi;
        private System.Windows.Forms.CheckBox FA1Ai;
        private System.Windows.Forms.CheckBox FA1Si;
        private System.Windows.Forms.CheckBox FA1Ci;
        private System.Windows.Forms.CheckBox FA1CI1;
        private System.Windows.Forms.CheckBox FA2Ci;
        private System.Windows.Forms.CheckBox FA2Bi;
        private System.Windows.Forms.CheckBox FA2Ai;
        private System.Windows.Forms.CheckBox FA2Si;
        private System.Windows.Forms.CheckBox FA2CI1;
        private System.Windows.Forms.CheckBox FA3Ci;
        private System.Windows.Forms.CheckBox FA3Ai;
        private System.Windows.Forms.CheckBox FA3Bi;
        private System.Windows.Forms.CheckBox FA3Si;
        private System.Windows.Forms.CheckBox FA3CI1;
        private System.Windows.Forms.CheckBox FA4Ci;
        private System.Windows.Forms.CheckBox FA4Bi;
        private System.Windows.Forms.CheckBox FA4Ai;
        private System.Windows.Forms.CheckBox FA4CI1;
        private System.Windows.Forms.CheckBox FA4Si;
        private System.Windows.Forms.CheckBox oflKorektor;
        private System.Windows.Forms.CheckBox cnKorektor;
        private System.Windows.Forms.CheckBox Cn1Korektor;
        private System.Windows.Forms.CheckBox KorektorBit;
        private System.Windows.Forms.CheckBox B0SUMR;
        private System.Windows.Forms.PictureBox pictureBox17;
        private System.Windows.Forms.PictureBox pictureBox23;
        private System.Windows.Forms.PictureBox pictureBox24;
    }
}

